__attribute__((weak))
int mydata;


int baz()
{
	return mydata;
}
