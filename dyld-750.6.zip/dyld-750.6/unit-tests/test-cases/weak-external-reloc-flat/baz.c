




int __attribute__((weak)) bar[] = { 30, 31, 32, 33 };


