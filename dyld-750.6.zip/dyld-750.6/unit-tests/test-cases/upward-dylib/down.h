extern int getdown();
extern int getdownsup();

